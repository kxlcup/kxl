//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CkU66698.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/hall",
			"/reveal",
			"/vs"
		],
		preloads: ["/assets/index-BX8Ptmfu.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BX8Ptmfu.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CgrxfnWk.js",
			"/assets/site-nav-Du1tinII.js",
			"/assets/team-card-znvPYMuK.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-DzlqpK5x.js", "/assets/site-nav-Du1tinII.js"]
	},
	"/hall": {
		filePath: "/workspace/src/routes/hall.tsx",
		children: void 0,
		preloads: [
			"/assets/hall-Z_z1WCgu.js",
			"/assets/site-nav-Du1tinII.js",
			"/assets/team-card-znvPYMuK.js"
		]
	},
	"/reveal": {
		filePath: "/workspace/src/routes/reveal.tsx",
		children: void 0,
		preloads: [
			"/assets/reveal-l6jPKw6u.js",
			"/assets/site-nav-Du1tinII.js",
			"/assets/team-card-znvPYMuK.js"
		]
	},
	"/vs": {
		filePath: "/workspace/src/routes/vs.tsx",
		children: void 0,
		preloads: ["/assets/vs-D998Rp8B.js", "/assets/site-nav-Du1tinII.js"]
	}
} });
//#endregion
export { tsrStartManifest };
