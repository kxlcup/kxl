const MAX_SIZE = 384;
const QUALITY = 0.72;
const MAX_INPUT_BYTES = 8 * 1024 * 1024;

export async function compressLogo(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) {
    throw new Error("Please upload a JPG, PNG, or WebP image.");
  }
  if (file.size > MAX_INPUT_BYTES) {
    throw new Error("Logo must be under 8 MB.");
  }

  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url);
    const canvas = document.createElement("canvas");
    canvas.width = MAX_SIZE;
    canvas.height = MAX_SIZE;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Could not process the image.");
    ctx.fillStyle = "#17120D";
    ctx.fillRect(0, 0, MAX_SIZE, MAX_SIZE);

    const scale = Math.max(MAX_SIZE / img.width, MAX_SIZE / img.height);
    const w = img.width * scale;
    const h = img.height * scale;
    const x = (MAX_SIZE - w) / 2;
    const y = (MAX_SIZE - h) / 2;
    ctx.drawImage(img, x, y, w, h);

    const dataUrl = canvas.toDataURL("image/jpeg", QUALITY);
    if (dataUrl.length > 700_000) {
      throw new Error("Logo is too detailed — try a simpler square image.");
    }
    return dataUrl;
  } finally {
    URL.revokeObjectURL(url);
  }
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not read that image."));
    img.src = src;
  });
}
