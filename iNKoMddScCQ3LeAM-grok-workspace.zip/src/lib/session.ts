const KEY = "ff_tournament_admin_session_vihaan_espx";
export const ADMIN_ID = "espx_admin";
export const ADMIN_PASSWORD = "khatri1k";

const memory: Record<string, string> = {};

export function safeSessionGet(key: string) {
  try {
    return sessionStorage.getItem(key);
  } catch {
    return memory[key] ?? null;
  }
}
export function safeSessionSet(key: string, val: string) {
  try {
    sessionStorage.setItem(key, val);
  } catch {
    memory[key] = val;
  }
}
export function safeSessionRemove(key: string) {
  try {
    sessionStorage.removeItem(key);
  } catch {
    delete memory[key];
  }
}

export function isAdminLoggedIn() {
  return safeSessionGet(KEY) === "true";
}
export function loginAdmin() {
  safeSessionSet(KEY, "true");
}
export function logoutAdmin() {
  safeSessionRemove(KEY);
}
